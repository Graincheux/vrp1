local cfg = {}

cfg = {
  thirst_per_minute = 2.5,
  hunger_per_minute = 1.25,
  overflow_damage_factor = 2,
  pvp = true,
  police = false
}

return cfg
